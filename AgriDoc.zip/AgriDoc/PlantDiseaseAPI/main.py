from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import uvicorn
import io
from PIL import Image
import os
from model_utils import load_model_and_labels, predict_image, get_recommendation

app = FastAPI(title="Plant Disease Detector API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # change in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MODEL, LABELS = load_model_and_labels()

class Prediction(BaseModel):
    label: str
    probability: float

class PredictResponse(BaseModel):
    predictions: List[Prediction]
    predicted_class: str
    predicted_probability: float
    severity: str
    recommendations: List[str]

@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": MODEL is not None}

@app.post("/predict", response_model=PredictResponse)
async def predict(file: UploadFile = File(...)):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")

    contents = await file.read()
    try:
        img = Image.open(io.BytesIO(contents)).convert("RGB")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Couldn't open image: {e}")

    preds = predict_image(MODEL, img, LABELS)

    top_label, top_prob = preds[0]
    recommendation = get_recommendation(top_label, top_prob)
    severity = recommendation["severity"]
    recs = recommendation["recommendations"]

    response = {
        "predictions": [{"label": p[0], "probability": float(p[1])} for p in preds],
        "predicted_class": top_label,
        "predicted_probability": float(top_prob),
        "severity": severity,
        "recommendations": recs,
    }
    return response

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))