# Integrated AgriDoc + PlantDiseaseAPI

This project is your original AgriDoc site with an added `PlantDiseaseAPI/` folder that contains a FastAPI backend for plant disease detection.

## How to use

1. Place your Keras model file at `PlantDiseaseAPI/model/model.h5`.
2. Ensure `PlantDiseaseAPI/labels.json` matches your model's output classes.
3. Install dependencies (preferably in a virtualenv):
   ```
   pip install -r PlantDiseaseAPI/requirements.txt
   ```
4. Run the API:
   ```
   cd PlantDiseaseAPI
   uvicorn main:app --reload
   ```
5. From your frontend, POST `multipart/form-data` to:
   `http://localhost:8000/predict` with the file field named `file`.

If you want me to wire the frontend to call this API automatically (update fetch/ajax calls), I can modify the web files in the project — tell me if you want that.