<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/weather.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tinos:ital,wght@0,400;0,700;1,400;1,700&display=swap"
      rel="stylesheet">
    <title>Weather Check System</title>
</head>
<body>
    <div class="box weather-box">
    
      <div class="left general-data">
        <div class="main">
          <input type="text" id="cityInput" placeholder="Enter a city (by default, New Delhi)">
          <br />
          <button id="search">Search</button>
        </div>
        <div class="general">
          <h3 id="city">City</h3>
          <h4 id="region">Region</h4>
          <h5 id="country">Country</h5>
          <br />
          <br />
          <h6 id="description">mostly ---</h6>
          <p id="temperature">40</p>
          <!-- image is added in "p" dynamically -->
        </div>
      </div>
    
      <div class="right predictions-data">
        <div class="hourly">
          <div>
            <p>Hourly forecast</p>
          </div>
          <div class="hour" id="hour">
            <!-- cards are entered dynamically -->
          </div>
        </div>
        <div class="daywise">
          <div>
            <p>10 days forecast</p>
          </div>
          <div class="day" id="day">
            <!-- cards are entered dynamically -->
          </div>
        </div>
      </div>
    
    </div>
    
    <!-- Footer -->
    <footer class="site-footer">
      <div class="footer-inner">
        <div class="footer-brand">
          <img src="images/logo.png" alt="AgriTech logo" class="footer-logo">
          <h3>AgriDoc</h3>
          <p>Empowering India's Farming Future</p>
          <div class="social-media">
            <a href="#" target="_blank" aria-label="Follow us on Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="#" target="_blank" aria-label="View our GitHub repositories">
              <i class="fab fa-github"></i>
            </a>
            <a href="#" target="_blank"
              aria-label="Connect with us on LinkedIn">
              <i class="fab fa-linkedin"></i>
            </a>
          </div>
        </div>
        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="main.html">Dashboard</a></li>
            <li><a href="feed-back.html">Feedback</a></li>
            <li><a href="chat.html">AI Assistant</a></li>
          </ul>
        </div>
        <div class="footer-links">
          <h4>Tools</h4>
          <ul>
            <li><a href="Crop Recommendation/templates/index.html">Crop Recommendation</a></li>
            <li><a href="Crop Yield Prediction/crop_yield_app/templates/index.html">Yield Prediction</a></li>
            <li><a href="Disease prediction/template/index.html">Disease Detector</a></li>
            <li><a href="Crop_Planning/templates/cropplan.html">Crop Planner</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">© 2025 AgriDoc - Created By Cropcoders</div>
    </footer>
    <!-- Floating Chatbot Button -->
<a href="#" id="chatbotBtn" title="Chat with us" aria-label="AI Assistant">
  <i class="fas fa-robot"></i>
</a>
    <script src="assets/js/weather.js"></script>
</body>
</html>
