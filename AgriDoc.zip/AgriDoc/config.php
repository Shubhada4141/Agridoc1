<?php
$dbuser="abc";
$dbpass="abc@123";
$host="localhost";
$db="agridoc";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>